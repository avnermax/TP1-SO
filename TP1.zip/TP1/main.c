#include "shellso.h"

int main(int argc, char *argv[]){

	shell(argc, argv);

    return 0;
}

